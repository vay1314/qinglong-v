return reply(
     [
          `你好` => `我不好`,
          `早上好`=>`good morning`
          `壁纸` => `https://acg.toubiec.cn/random.php`
          `涩图` => `https://acg.toubiec.cn/random.php`
     ]
)